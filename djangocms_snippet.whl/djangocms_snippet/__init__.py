__version__ = '3.0.0'

default_app_config = 'djangocms_snippet.apps.SnippetConfig'
